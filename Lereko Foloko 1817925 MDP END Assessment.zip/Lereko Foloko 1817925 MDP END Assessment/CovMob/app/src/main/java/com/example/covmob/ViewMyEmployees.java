package com.example.covmob;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ViewMyEmployees extends AppCompatActivity {
    EditText view_my_employees;
    TextView text_display_all_emp;
    Button search_employee, update_emp;
    public static String organizationName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_my_employees);

        view_my_employees =(EditText) findViewById(R.id.view_my_employees);
        text_display_all_emp = (TextView) findViewById(R.id.text_display_all_emp);

        // when button search employees is clicked
        search_employee = (Button) findViewById(R.id.search_employee);
        search_employee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                organizationName = view_my_employees.getText().toString();
                getMyEmployees();
            }
        });
        // when button update info is clicked
        update_emp = (Button) findViewById(R.id.update_emp);
        update_emp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),DailyRecords.class);
                startActivity(intent);
            }
        });
    }
    // get all employees registered under certain organization
    private void getMyEmployees() {
        organizationName = view_my_employees.getText().toString();
        DBHelper DataBase = new DBHelper(this);

        String id = null, name = null, email = null, phone = null, origin = null, reason = null, Orgname = null;

        Cursor newcursor = DataBase.getAllMyEmployees(organizationName);

        newcursor.moveToNext();
        if (newcursor.getCount() <=0 )
        {
            Toast.makeText(this, "There is Nothing to display!", Toast.LENGTH_SHORT).show();
        }
        else
        {
            id = newcursor.getString(0);
            name = newcursor.getString(2);
            email = newcursor.getString(3);
            phone = newcursor.getString(4);
            origin = newcursor.getString(6);
            Orgname = newcursor.getString(9);

            text_display_all_emp.setText(id+"\t"+name+" \t"+email+"\t"+phone+"\t"+origin+"\t"+Orgname+"\n");
        }
    }
}