package com.example.covmob;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class CitizenDetails extends AppCompatActivity {
    EditText view_my_details;
    Button search_mine, view_update;
    TextView text_display;
    public static String searchClient;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_citizen_details);

        view_my_details = (EditText) findViewById(R.id.view_my_details);
        text_display = (TextView) findViewById(R.id.text_display);

        // when search button is clicked
        search_mine = (Button) findViewById(R.id.search_mine);
        search_mine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchClient = view_my_details.getText().toString();
                getYourDetails();
            }
        });
        // when button update info is clicked
        view_update = (Button) findViewById(R.id.view_update);
        view_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), DailyRecords.class);
                startActivity(intent);
            }
        });
    }

    private void getYourDetails() {
        searchClient = view_my_details.getText().toString();
        DBHelper DataBase = new DBHelper(this);

        String id = null, name = null, email = null, phone = null, origin = null, gender = null, Orgname = null;

        Cursor newcursor = DataBase.getCitizenD(searchClient);

        newcursor.moveToNext();
        if (newcursor.getCount() <= 0)
        {
            Toast.makeText(this, "ID Not Registered!", Toast.LENGTH_SHORT).show();
        }
        else
        {
            id = newcursor.getString(0);
            name = newcursor.getString(2);
            email = newcursor.getString(3);
            phone = newcursor.getString(4);
            origin = newcursor.getString(6);
            gender = newcursor.getString(7);
            Orgname = newcursor.getString(9);

            text_display.setText(id+"\t"+name+" \t"+email+"\t"+phone+"\t"+origin+"\t "+gender+"\t"+Orgname+"\n");
        }
    }
}