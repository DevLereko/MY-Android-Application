package com.example.covmob;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {

    //---------------------Database name and tables Declaration and assignments----//
    public static final String DBName = "CovMonitoring.db";
    public static final String TBLAuthority = "AuthorityTable";
    public static final String TBLHealth = "HealthOrganization";
    public static final String TBLNonHealth ="NonHealth";
    public static final String TBLCitizen = "Citizens";
    public static final String TBLVaccination = "VaccinationDetails";

    //---------------------Authority Table ---------------//
    public static final String EmailAddress = "auth_email";
    public static final String Name = "auth_name";
    public static final String PhoneNumber = "auth_phone";
    public static final String PasswordAuthority = "auth_pass";

    //---------------------Health organization preparation ------------------//
    public static final String OrganizationID = "organization_id";
    public static final String OrganizationName = "organization_name";
    public static final String OrganizationEmail = "organization_email";
    public static final String OrganizationContact = "organization_contact";
    public static final String PhysicalAddress = "physical_address";
    public static final String PostalCode = "postal_code";
    public static final String NoEmployees = "no_of_employees";
    public static final String OrganizationType = "organization_type";
    public static final String HealthPassword = "health_password";

    //---------------------non health organization ---------------//
    public static final String NonOrganizationId = "non_health_org_id";
    public static final String NonOrganizationName = "non_health_org_name";
    public static final String NonOrganizationEmail = "non_health_org_email";
    public static final String NonOrganizationContact = "non_health_contact";
    public static final String NonPhysicalAddress = "non_health_org_address";
    public static final String NonPostalCode = "non_health_org_code";
    public static final String NonNoEmployees = "non_health_employees";
    public static final String NonOrganizationType = "non_health_org_type";
    public static final String NonPassword = "non_health_password";

    //--------------------Citizens table-----------------------------//
    public static final String NationalID = "national_id";
    public static final String RegistrationDate = "reg_date";
    public static final String CitizenName = "citizen_name";
    public static final String CitizenEmail = "citizen_email";
    public static final String CitizenPhone = "citizen_phone";
    public static final String CitizenTemperature = "temp_citizen";
    public static final String CitizenPlace = "citizen_origin";
    public static final String CitizenGender = "rbn_gender";
    public static final String CitizenPassword = "citizen_password";
    public static final String CitizenOrgName = "citizen_organization_Name";
    public static final String CitizenOrgID = "citizen_organization_id";

    // -----------------vaccination details table ---------------------//
    public static final String citizenID = "citizen_vacc_id";
    public static final String VaccinationID = "vacc_Id";
    public static final String VaccinationDate = "vacc_date";
    public static final String CitizenVaccName = "vacc_name";
    public static final String CitizenTemp = "citizen_tem";
    public static final String CitizenVaccPhone = "citizen_vacc_phone";
    public static final String VaccGender = "rbn_vacc_gender";
    public static final String VaccDistrict = "place_of_origin";
    public static final String VaccStatus = "vacc_status";
    public static final String Reason = "reason";
    public static final String OrgVaccName = "org_vacc_name";
    public static final String OrgVaccID = "org_vacc_id";

    //---------------------Table creations -----------------------//
    public DBHelper(Context context) { super(context, DBName, null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase DBMonitor) {
        //-----------------Authority Table Creation -----------//
        String authority = "CREATE TABLE IF NOT EXISTS "+TBLAuthority+ "(auth_email TEXT primary key not null, auth_name TEXT not null," +
                " auth_phone INTEGER not null, auth_pass TEXT not null )";

        //----------------Health Organization Table Creation -----------------//
        String healthOrganization = "CREATE TABLE IF NOT EXISTS "+TBLHealth+ "(organization_id TEXT primary key not null," +
                " organization_name TEXT not null," +
                "organization_email TEXT not null, organization_contact INTEGER not null, physical_address TEXT not null," +
                " postal_code TEXT not null," +
                "no_of_employees INTEGER not null, organization_type TEXT not null, health_password TEXT not null)";

        //----------------Non Heath organization -------------------------------//
        String nonHealth = " CREATE TABLE IF NOT EXISTS "+TBLNonHealth+ "(non_health_org_id TEXT primary key not null," +
                " non_health_org_name TEXT not null," +
                "non_health_org_email TEXT not null, non_health_contact INTEGER not null, non_health_org_address TEXT not null," +
                " non_health_org_code TEXT not null, non_health_employees INTEGER not null, non_health_org_type TEXT not null, " +
                "non_health_password TEXT not null)";

        //-----------------citizen Table Creation------------------//
        String citizen = "CREATE TABLE IF NOT EXISTS "+TBLCitizen+ "(national_id INTEGER primary key not null, reg_date DATE not null," +
                " citizen_name TEXT not null, " +
                "citizen_email TEXT not null, citizen_phone INTEGER not null, temp_citizen DOUBLE not null," +
                " citizen_origin TEXT not null, rbn_gender TEXT not null, " +
                "citizen_password TEXT not null, citizen_organization_Name TEXT, citizen_organization_id TEXT)";

        // ----------------vaccination details table creation -----------------//
        String vaccination = " CREATE TABLE IF NOT EXISTS "+TBLVaccination+ "(citizen_vacc_id INTEGER not null," +
                " vacc_id TEXT primary key not null, " +
                "vacc_date DATE not null, vacc_name TEXT not null, citizen_tem DOUBLE not null, citizen_vacc_phone INTEGER not null," +
                " rbn_vacc_gender TEXT not null, place_of_origin TEXT not null," +
                "vacc_status TEXT not null, reason TEXT, org_vacc_name TEXT, org_vacc_id TEXT)";

        DBMonitor.execSQL(authority);
        DBMonitor.execSQL(healthOrganization);
        DBMonitor.execSQL(nonHealth);
        DBMonitor.execSQL(citizen);
        DBMonitor.execSQL(vaccination);
    }

    @Override
    public void onUpgrade(SQLiteDatabase DBMonitor, int oldVersion, int newVersion) {
        //------------------Droping existing tables ---------------------//

        String dropAuthority = "DROP TABLE IF EXISTS "+TBLAuthority;
        String dropHealth = "DROP TABLE IF EXISTS "+TBLHealth;
        String dropNonHealth = "DROP TABLE IF EXISTS "+TBLNonHealth;
        String dropCitizen = "DROP TABLE IF EXISTS "+TBLCitizen;
        String dropVaccination = "DROP TABLE IF EXISTS "+TBLVaccination;

        DBMonitor.execSQL(dropAuthority);
        DBMonitor.execSQL(dropHealth);
        DBMonitor.execSQL(dropNonHealth);
        DBMonitor.execSQL(dropCitizen);
        DBMonitor.execSQL(dropVaccination);
        onCreate(DBMonitor);
    }
    //---------------------creating writable databases and contentValues -------------------//
    //------------------------Table Authority -----------------------//
    public boolean InsertAuthority (String auth_email, String auth_name, String auth_phone, String auth_pass) {

        //-----------------Creating a writable Database ----------------------//
        SQLiteDatabase DBMonitor = this.getWritableDatabase();

        // -----------------Creating Content Values ---------------//
        ContentValues contentValues = new ContentValues();
        contentValues.put(EmailAddress, auth_email);
        contentValues.put(Name, auth_name);
        contentValues.put(PhoneNumber, auth_phone);
        contentValues.put(PasswordAuthority, auth_pass);

        Long inserted = DBMonitor.insert(TBLAuthority, null, contentValues);
        if (inserted==-1)
            return false;
        else
            return true;
    }
    //----------------------Table Health organization --------//
    public boolean InsertHealth (String organization_id, String organization_name, String organization_email, String organization_contact,
                                 String physical_address, String postal_code, String no_of_employees, String organization_type,
                                 String health_password) {
        //---------------getting writable database ----------------//
        SQLiteDatabase DBMonitor = this.getWritableDatabase();

        //--------------creating contentValues --------------------//
        ContentValues health_org = new ContentValues();
        health_org.put(OrganizationID, organization_id);
        health_org.put(OrganizationName, organization_name);
        health_org.put(OrganizationEmail, organization_email);
        health_org.put(OrganizationContact, organization_contact);
        health_org.put(PhysicalAddress, physical_address);
        health_org.put(PostalCode, postal_code);
        health_org.put(NoEmployees, no_of_employees);
        health_org.put(OrganizationType, organization_type);
        health_org.put(HealthPassword, health_password);

        Long result = DBMonitor.insert(TBLHealth,null, health_org);
        if (result==-1)
            return false;
        else
            return true;
    }
    //-----------------------inserting into table non health organization -----------------------//
    public boolean InsertNonHealth (String non_health_org_id, String non_health_org_name, String non_health_org_email, String non_health_contact,
                                    String non_health_org_address, String non_health_org_code, String non_health_employees,
                                    String non_health_org_type, String non_health_password) {
    //------------------getting writable database -------------------------//
        SQLiteDatabase DBMonitor = this.getWritableDatabase();

        //-----------------content values ---------------------------//
        ContentValues nonHealthReg = new ContentValues();
        nonHealthReg.put(NonOrganizationId, non_health_org_id);
        nonHealthReg.put(NonOrganizationName, non_health_org_name);
        nonHealthReg.put(NonOrganizationEmail, non_health_org_email);
        nonHealthReg.put(NonOrganizationContact, non_health_contact);
        nonHealthReg.put(NonPhysicalAddress, non_health_org_address);
        nonHealthReg.put(NonPostalCode, non_health_org_code);
        nonHealthReg.put(NonNoEmployees, non_health_employees);
        nonHealthReg.put(NonOrganizationType, non_health_org_type);
        nonHealthReg.put(NonPassword, non_health_password);

        Long regHealthNon = DBMonitor.insert(TBLNonHealth, null, nonHealthReg);
        if (regHealthNon==-1)
            return false;
        else
            return true;
    }
    //-----------------------Inserting into Citizens table ------------------------//
    public boolean InsertCitizen (String national_id, String reg_gate, String citizen_name, String citizen_email, String citizen_phone, String temp_citizen,
                                  String citizen_origin,
                                  String rbn_gender, String citizen_password, String citizen_organization_Name, String citizen_organization_id){
        //-------------------getting writable database -----------------------//
        SQLiteDatabase DBMonitor = this.getWritableDatabase();
        //-----------------------------creating contentvalues ----------------//
        ContentValues citizenContent = new ContentValues();
        citizenContent.put(NationalID, national_id);
        citizenContent.put(RegistrationDate, reg_gate);
        citizenContent.put(CitizenName, citizen_name);
        citizenContent.put(CitizenEmail, citizen_email);
        citizenContent.put(CitizenPhone, citizen_phone);
        citizenContent.put(CitizenTemperature, temp_citizen);
        citizenContent.put(CitizenPlace, citizen_origin);
        citizenContent.put(CitizenGender, rbn_gender);
        citizenContent.put(CitizenPassword, citizen_password);
        citizenContent.put(CitizenOrgName, citizen_organization_Name);
        citizenContent.put(CitizenOrgID, citizen_organization_id);

        Long registerCitizen = DBMonitor.insert(TBLCitizen, null, citizenContent);
        if (registerCitizen==-1)
            return false;
        else
            return true;
    }
    //------------------------inserting into vaccination table ------------------//
    public boolean InsertVaccination (String citizen_vacc_id, String vacc_id, String vacc_date, String vacc_name, String citizen_tem, String citizen_vacc_phone,
                                      String rbn_vacc_gender, String place_of_origin, String vacc_status, String reason,
                                      String org_vacc_name, String org_vacc_id) {
        // ------------------------creating writable database ----------------------//
        SQLiteDatabase DBMonitor = this.getWritableDatabase();
        //-------------------------creating content values ------------------------//
        ContentValues vaccineValues = new ContentValues();
        vaccineValues.put(citizenID, citizen_vacc_id);
        vaccineValues.put(VaccinationID, vacc_id);
        vaccineValues.put(VaccinationDate, vacc_date);
        vaccineValues.put(CitizenVaccName, vacc_name);
        vaccineValues.put(CitizenTemp, citizen_tem);
        vaccineValues.put(CitizenVaccPhone, citizen_vacc_phone);
        vaccineValues.put(VaccGender, rbn_vacc_gender);
        vaccineValues.put(VaccDistrict, place_of_origin);
        vaccineValues.put(VaccStatus, vacc_status);
        vaccineValues.put(Reason, reason);
        vaccineValues.put(OrgVaccName, org_vacc_name);
        vaccineValues.put(OrgVaccID, org_vacc_id);

        Long insertVaccine = DBMonitor.insert(TBLVaccination, null, vaccineValues);
        if (insertVaccine==-1)
            return false;
        else
            return true;
    }
    //--------------------search for organization From the table ------------------//
    public Cursor getCitizenID (String national_id) {

        SQLiteDatabase DBMonitor = this.getWritableDatabase();

        String selectQuery = " select * from Citizens where national_id = ?";

        Cursor coose = null;

        if (DBMonitor != null) {
            coose = DBMonitor.rawQuery(selectQuery, new String[]{national_id});
        }
        return coose;
    }
    //search citizen to update temperatures ----------------//
    public Cursor getCitizenDetails (String national_id) {

        SQLiteDatabase DBMonitor = this.getWritableDatabase();

        String selectId = " select * from Citizens where national_id = ?";

        Cursor retrieve = null;
        if (DBMonitor != null) {
            retrieve = DBMonitor.rawQuery(selectId, new String[]{national_id});
        }
        return retrieve;
    }
    // searching for health organization -------------//
    public Cursor getHealthDetails (String organization_id) {

        SQLiteDatabase DBMonitor = this.getWritableDatabase();

        String selectIt = " select * from HealthOrganization where organization_id = ? ";

        Cursor bringIt = null;
        if (DBMonitor != null) {
            bringIt = DBMonitor.rawQuery(selectIt, new String[]{organization_id});
        }
        return bringIt;
    }
    // searching for the non health organization
    public Cursor getNonHealthDetails (String non_health_org_id) {

        SQLiteDatabase DBMonitor = this.getWritableDatabase();

        String selectNon = " select * from NonHealth where non_health_org_id = ? ";

        Cursor collect = null;
        if (DBMonitor != null) {
            collect = DBMonitor.rawQuery(selectNon, new String[]{non_health_org_id});
        }
        return collect;
    }
    //-------------------search id ------------------//
    public Cursor getSearchedID(String non_health_org_name) {

        SQLiteDatabase DBMonitor = this.getReadableDatabase();

        String query = " Select * from NonHealth where non_health_org_name like ?";

        Cursor cursor = null;

        if (DBMonitor != null) {
            cursor = DBMonitor.rawQuery(query,new String[]{non_health_org_name});
        }
        return cursor;
    }
    // --------------------get organizations with people who vaccinated
    public Cursor getVaccinatedOrg (String org_vacc_name, String vacc_status) {

        SQLiteDatabase DBMonitor = this.getWritableDatabase();

        String selector = " select * from VaccinationDetails where org_vacc_name like ? AND vacc_status = ? ";

        Cursor getIt = null;

        if (DBMonitor != null) {
            getIt = DBMonitor.rawQuery(selector,new String[]{org_vacc_name,vacc_status});
        }
        return getIt;
    }
    //----------------get all people vaccinated by their districts
    public Cursor getDistricts (String place_of_origin, String vacc_status) {

        SQLiteDatabase DBMonitor = this.getWritableDatabase();

        String selector = " select * from VaccinationDetails where place_of_origin like ? AND vacc_status = ? ";

        Cursor district = null;

        if (DBMonitor != null) {
            district = DBMonitor.rawQuery(selector,new String[]{place_of_origin,vacc_status});
        }
        return district;
    }
    //---------------------select by status an gender ---------------//
    public Cursor getGender(String rbn_vacc_gender, String vacc_status) {

        SQLiteDatabase DBMonitor = this.getWritableDatabase();

        String selector = " select * from VaccinationDetails where rbn_vacc_gender like ? AND vacc_status = ? ";

        Cursor gender = null;

        if (DBMonitor != null) {
            gender = DBMonitor.rawQuery(selector,new String[]{rbn_vacc_gender,vacc_status});
        }
        return gender;
    }
    // get all employees under searched organization
    public Cursor getAllMyEmployees(String citizen_organization_Name) {

        SQLiteDatabase DBMonitor = this.getWritableDatabase();

        String selector = " select * from Citizens where citizen_organization_Name like ? ";

        Cursor employees = null;

        if (DBMonitor != null) {
            employees = DBMonitor.rawQuery(selector,new String[]{citizen_organization_Name});
        }
        return employees;
    }
    // get citizen details -------//
    public Cursor getCitizenD (String national_id) {

        SQLiteDatabase DBMonitor = this.getWritableDatabase();

        String selector = " select * from Citizens where national_id like ? ";

        Cursor ids = null;

        if (DBMonitor != null) {
            ids = DBMonitor.rawQuery(selector,new String[]{national_id});
        }
        return ids;
    }
    //get all users of the system
    // get all organizations registered as non health
    public Cursor getAllNonHealth () {

        SQLiteDatabase DBMonitor = this.getWritableDatabase();

        String selector = " select * from NonHealth ";

        Cursor nonHealth = null;

        if (DBMonitor != null) {
            nonHealth = DBMonitor.rawQuery(selector,null);
        }
        return nonHealth;
    }
    // get all Health organizations
    public Cursor getAllHealth () {

        SQLiteDatabase DBMonitor = this.getWritableDatabase();

        String selector = " select * from HealthOrganization ";

        Cursor health = null;

        if (DBMonitor != null) {
            health = DBMonitor.rawQuery(selector,null);
        }
        return health;
    }
    // get all registered citizens
    public Cursor getAllCitizens () {

        SQLiteDatabase DBMonitor = this.getWritableDatabase();

        String selector = " select * from Citizens ";

        Cursor citizen = null;

        if (DBMonitor != null) {
            citizen = DBMonitor.rawQuery(selector,null);
        }
        return citizen;
    }
    // get all vaccinated people
    public Cursor getAllVaccinated() {
        SQLiteDatabase DBMonitor = this.getReadableDatabase();

        String query = " select * from VaccinationDetails where vacc_status = 'Vaccinated'";
        Cursor cursor = null;
        if (DBMonitor != null) {
            cursor = DBMonitor.rawQuery(query, null);
        }
        return cursor;
    }
    // get all people not vaccinated and their reasons
    public Cursor getAllNotVaccinated () {
        SQLiteDatabase DBMonitor = this.getReadableDatabase();

        String query = " select * from VaccinationDetails where vacc_status = 'Not_Vaccinated'";
        Cursor cursor = null;
        if (DBMonitor != null )
        {
            cursor = DBMonitor.rawQuery(query, null);
        }
        return cursor;
    }
    //--------------------checking if national ID ---------------------------------//
    public boolean checkNationalID(String national_id) {
        SQLiteDatabase DBMonitor = this.getWritableDatabase();

        Cursor cursor = DBMonitor.rawQuery("select * from Citizens where national_id = ? ", new String[] {national_id});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }
    //--------------------checking if user already exist by email------------------//
    public boolean checkUserEmail(String auth_email) {

        SQLiteDatabase DBMonitor = this.getWritableDatabase();

        Cursor cursor = DBMonitor.rawQuery("select * from AuthorityTable where auth_email = ? ", new String[] {auth_email});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }
    //--------------------checking existence of user from database -----------------//
    public boolean checkOrganization (String organization_id) {

        SQLiteDatabase DBMonitor = this.getWritableDatabase();

        Cursor cursor = DBMonitor.rawQuery("select * from HealthOrganization where organization_id = ? ", new String[] {organization_id});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }
    //-------------------check Non Health Id -----------------------------//
    public boolean checkNonId (String non_health_org_id) {
        SQLiteDatabase DBMonitor = this.getWritableDatabase();

        Cursor cursor = DBMonitor.rawQuery("select * from NonHealth where non_health_org_id = ? ", new String[] {non_health_org_id});
        if (cursor.getCount() > 0 )
            return true;
        else
            return false;
    }
    // ------------------ update temperatures and other details -------------//
    public boolean UpdateRecords (String national_id, String reg_date, String citizen_name, String temp_citizen,
                               String citizen_phone,
                               String citizen_origin, String citizen_organization_name) {
        // getting writable database and content values--------------//
        SQLiteDatabase DBMonitor = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(NationalID, national_id);
        values.put(RegistrationDate, reg_date);
        values.put(CitizenName, citizen_name);
        values.put(CitizenTemperature, temp_citizen);
        values.put(CitizenPhone, citizen_phone);
        values.put(CitizenPlace, citizen_origin);
        values.put(CitizenOrgName, citizen_organization_name);

        DBMonitor.update(TBLCitizen, values, "national_id = ? ", new String[]{national_id});
        return true;
    }
    // updating non health organization
    public boolean UpdateNonOrg (String non_health_org_id, String non_health_org_name, String non_health_org_email, String non_health_contact,
    String no_of_employees, String non_health_password) {
        // getting content values and writable database
        SQLiteDatabase DBMonitor = this.getWritableDatabase();
        ContentValues updateValues = new ContentValues();
        updateValues.put(NonOrganizationId, non_health_org_id);
        updateValues.put(NonOrganizationName, non_health_org_name);
        updateValues.put(NonOrganizationEmail, non_health_org_email);
        updateValues.put(NonOrganizationContact, non_health_contact);
        updateValues.put(NonNoEmployees, no_of_employees);
        updateValues.put(NonPassword, non_health_password);

        DBMonitor.update(TBLNonHealth, updateValues, "non_health_org_id = ? ", new String[]{non_health_org_id});
        return true;
    }
    // updating details for the health organizations
    public boolean UpdateHealth (String organization_id, String organization_name, String organization_email, String organization_contact,
                                 String no_of_employees, String health_password) {
        //getting writable database and content values
        SQLiteDatabase DBMonitor = this.getWritableDatabase();
        ContentValues updateHealth = new ContentValues();
        updateHealth.put(OrganizationID, organization_id);
        updateHealth.put(OrganizationName, organization_name);
        updateHealth.put(OrganizationEmail, organization_email);
        updateHealth.put(OrganizationContact, organization_contact);
        updateHealth.put(NoEmployees, no_of_employees);
        updateHealth.put(HealthPassword, health_password);

        DBMonitor.update(TBLHealth,updateHealth, "organization_id = ? ",new String[]{organization_id});
        return true;
    }
    //delete searched data
    public Integer deleteData (String national_id) {
        SQLiteDatabase DBMonitor = this.getWritableDatabase();
        return DBMonitor.delete(TBLCitizen, "national_id = ? ", new String[]{national_id});
    }
    //deleting organization from database -------------------//
    public Integer deleteNoN (String non_health_org_id) {
        SQLiteDatabase DBMonitor = this.getWritableDatabase();
        return DBMonitor.delete(TBLNonHealth, "non_health_org_id = ? ", new String[]{non_health_org_id});
    }
    //deleting health organization from the database -------------//
    public Integer deleteHealth (String organization_id) {
        // getting writable database and content values
        SQLiteDatabase DBMonitor = this.getWritableDatabase();
        return DBMonitor.delete(TBLHealth, "organization_id = ? ", new String[]{organization_id});
    }
    //--------------------------LOGIN DETAILS FOR DIFFERENT USERS ----------------//
    // checking login information for Authority
   public boolean checkAuthorityEmailPass (String auth_email, String auth_pass) {
        SQLiteDatabase DBMonitor = this.getWritableDatabase();

        Cursor cursor = DBMonitor.rawQuery(" select * from AuthorityTable where auth_email = ? AND auth_pass = ? ",
                new String[]{auth_email, auth_pass});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }
   // checking login information for citizen
   public boolean checkCitizenEmailPass (String citizen_email, String citizen_password) {
        SQLiteDatabase DBMonitor = this.getWritableDatabase();

        Cursor cursor = DBMonitor.rawQuery(" select * from Citizens where citizen_email = ? AND citizen_password = ? ",
                new String[]{citizen_email, citizen_password});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }
    // checking login information for health
   public boolean checkHealthEmailPass (String organization_email, String health_password) {
        SQLiteDatabase DBMonitor = this.getWritableDatabase();

        Cursor cursor = DBMonitor.rawQuery(" select * from HealthOrganization where organization_email = ? AND health_password = ? ",
                new String[]{organization_email, health_password});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
   }
   // checking login information for Non Health organization
   public boolean checkNonHealthEmailPass (String non_health_org_email, String non_health_password) {
        SQLiteDatabase DBMonitor = this.getWritableDatabase();

        Cursor cursor = DBMonitor.rawQuery( " select * from NonHealth where non_health_org_email = ? AND non_health_password = ? ",
                new String[]{non_health_org_email, non_health_password});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
   }

}
