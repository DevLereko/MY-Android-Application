package com.example.covmob;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Reports extends AppCompatActivity {

    LinearLayout more_reports;
    String[] status = {"Vaccinated", "Not_Vaccinated"};
    Spinner spinner_status;
    TextView text_vacc;

    EditText org_status;
    Button search_org_status, view_all_vaccinated, not_vaccreasons;

    public static String organizationStatus;
    public static String string;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reports);

        spinner_status = (Spinner) findViewById(R.id.spinner_status);
        ArrayAdapter<String> myadapter = new ArrayAdapter<String>(Reports.this, android.R.layout.simple_spinner_item,status);
        myadapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_status.setAdapter(myadapter);

        org_status = (EditText) findViewById(R.id.org_status);
        text_vacc = (TextView) findViewById(R.id.text_vacc);
        final DBHelper databases = new DBHelper(this);

        // -----------------when more reports layout is clicked ----------
        more_reports = (LinearLayout) findViewById(R.id.more_reports);
        more_reports.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MoreReports.class);
                startActivity(intent);
            }
        });
        // ---------------------when search button is clicked -------------
        search_org_status = (Button) findViewById(R.id.search_org_status);
        search_org_status.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                organizationStatus = org_status.getText().toString();
                string = spinner_status.getSelectedItem().toString();
                getVaccinatedOrganization();
            }
        });
        //when button view all vaccinated is clicked
        view_all_vaccinated = (Button) findViewById(R.id.view_all_vaccinated);
        view_all_vaccinated.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getVaccinated();
            }
        });
        //when button view all not vaccinated and reasons
        not_vaccreasons = (Button) findViewById(R.id.not_vaccreasons);
        not_vaccreasons.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getNotVaccinated();
            }
        });
    }
    // ----------------search organization by vaccination status -----------//
    private void getVaccinatedOrganization() {
        organizationStatus = org_status.getText().toString();
        string = spinner_status.getSelectedItem().toString();

        DBHelper DataBase = new DBHelper(this);

        String id = null, date = null, name = null, phone = null, status = null, Orgname = null;

        Cursor newcursor = DataBase.getVaccinatedOrg(organizationStatus, string);

        newcursor.moveToNext();
        if (newcursor.getCount() <=0 )
        {
            Toast.makeText(this, "There is Nothing to display!", Toast.LENGTH_SHORT).show();
        }
        else
        {
            id = newcursor.getString(0);
            date = newcursor.getString(2);
            name = newcursor.getString(3);
            phone = newcursor.getString(5);
            status = newcursor.getString(8);
            Orgname = newcursor.getString(10);

            text_vacc.setText(id+"\t"+date+" \t"+name+"\t"+phone+"\t"+status+"\t "+Orgname+"\n");
        }
    }
    // get all people vaccinated
    public void getVaccinated () {

        DBHelper DataBase = new DBHelper(this);

        String id = null, date = null, name = null, phone = null, status = null, Orgname = null;

        Cursor newcursor = DataBase.getAllVaccinated();

        newcursor.moveToNext();
        if (newcursor.getCount() <=0 )
        {
            Toast.makeText(this, "There is Nothing to display!", Toast.LENGTH_SHORT).show();
        }
        else
        {
            id = newcursor.getString(0);
            date = newcursor.getString(2);
            name = newcursor.getString(3);
            phone = newcursor.getString(5);
            status = newcursor.getString(8);
            Orgname = newcursor.getString(10);

            text_vacc.setText(id+"\t"+date+" \t"+name+"\t"+phone+"\t"+status+"\t "+Orgname+"\n");
        }
    }
    // get all not vaccinated and reasons
    public void getNotVaccinated () {

        DBHelper DataBase = new DBHelper(this);

        String id = null, date = null, name = null, phone = null, status = null, reason = null, Orgname = null;

        Cursor newcursor = DataBase.getAllNotVaccinated();

        newcursor.moveToNext();
        if (newcursor.getCount() <=0 )
        {
            Toast.makeText(this, "There is Nothing to display!", Toast.LENGTH_SHORT).show();
        }
        else
        {
            id = newcursor.getString(0);
            date = newcursor.getString(2);
            name = newcursor.getString(3);
            phone = newcursor.getString(5);
            status = newcursor.getString(8);
            reason = newcursor.getString(9);
            Orgname = newcursor.getString(10);

            text_vacc.setText(id+"\t"+date+" \t"+name+"\t"+phone+"\t"+status+"\t "+reason+"\t"+Orgname+"\n");
        }
    }
}