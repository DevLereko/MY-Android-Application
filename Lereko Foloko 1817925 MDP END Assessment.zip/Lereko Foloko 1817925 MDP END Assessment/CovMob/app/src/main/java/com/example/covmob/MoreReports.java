package com.example.covmob;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MoreReports extends AppCompatActivity {
    LinearLayout back;
    Button search_gender, search_vacc_district;
    TextView text_vaccine;
    Spinner search_place, spinner_vacc, gender_search, search_status;
    String[] places = {"Maseru", "Botha-Bothe", "Leribe", "Berea", "Mafeteng", "Mohale's Hoek",
            "Mokhotlong", "Thaba-Tseka", "Qacha's Nek", "Quthing"};
    String[] strings = {"Vaccinated", "Not_Vaccinated"};
    String[] gender = {"Male", "Female"};

    public static String genders, districts, statuses;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_more_reports);

        text_vaccine = (TextView) findViewById(R.id.text_vaccine) ;


        //--------------------Drop down for district selection--------------//
        search_place = (Spinner) findViewById(R.id.search_place);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(MoreReports.this, android.R.layout.simple_spinner_item, places);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        search_place.setAdapter(adapter);

        //--------------------Drop down for vaccination selection------------//
        spinner_vacc = (Spinner) findViewById(R.id.spinner_vacc);

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(MoreReports.this, android.R.layout.simple_spinner_item, strings);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_vacc.setAdapter(arrayAdapter);

        //--------------------gender selection ---------------------//
        gender_search = (Spinner) findViewById(R.id.gender_search);

        ArrayAdapter<String> genderSelection = new ArrayAdapter<>(MoreReports.this, android.R.layout.simple_spinner_item,gender);
        genderSelection.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        gender_search.setAdapter(genderSelection);

        //--------------------Status on gender-------------------//
        search_status = (Spinner) findViewById(R.id.search_status);

        ArrayAdapter<String> status = new ArrayAdapter<>(MoreReports.this, android.R.layout.simple_spinner_item, strings);
        status.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        search_status.setAdapter(status);

        // --------------- when more reports is clicked ---------------//
        back = (LinearLayout) findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Reports.class);
                startActivity(intent);
            }
        });
        // when button seach for district is clicked
        search_vacc_district = (Button) findViewById(R.id.search_vacc_district);
        search_vacc_district.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                districts = search_place.getSelectedItem().toString();
                statuses = search_status.getSelectedItem().toString();
                getByDistricts ();
            }
        });
        // get information searched by gender
        search_gender = (Button) findViewById(R.id.search_gender);
        search_gender.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                genders = gender_search.getSelectedItem().toString();
                statuses = search_status.getSelectedItem().toString();
                getByGender();
            }
        });
    }
    // ------------------------display by district name, different statuses
    private void getByDistricts() {

        districts = search_place.getSelectedItem().toString();
        statuses = search_status.getSelectedItem().toString();

        DBHelper DataBase = new DBHelper(this);

        String id = null, date = null, name = null, phone = null, place = null, status = null, Orgname = null;

        Cursor newcursor = DataBase.getDistricts(districts, statuses);

        newcursor.moveToNext();
        if (newcursor.getCount() <=0 )
        {
            Toast.makeText(this, "There is Nothing to display!", Toast.LENGTH_SHORT).show();
        }
        else
        {
            id = newcursor.getString(0);
            date = newcursor.getString(2);
            name = newcursor.getString(3);
            phone = newcursor.getString(5);
            place = newcursor.getString(7);
            status = newcursor.getString(8);
            Orgname = newcursor.getString(10);

            text_vaccine.setText(id+"\t"+date+" \t"+name+"\t"+phone+"\t"+place+"\t"+status+"\t "+Orgname+"\n");
        }
    }
    // ----------------------display by gender different statuses
    public void getByGender () {

        genders = gender_search.getSelectedItem().toString();
        statuses = search_status.getSelectedItem().toString();

        DBHelper DataBase = new DBHelper(this);

        String id = null, date = null, name = null, phone = null, gender = null, status = null, Orgname = null;

        Cursor newcursor = DataBase.getGender(genders,statuses);

        newcursor.moveToNext();
        if (newcursor.getCount() <=0 )
        {
            Toast.makeText(this, "There is Nothing to display!", Toast.LENGTH_SHORT).show();
        }
        else
        {
            id = newcursor.getString(0);
            date = newcursor.getString(2);
            name = newcursor.getString(3);
            phone = newcursor.getString(5);
            gender = newcursor.getString(6);
            status = newcursor.getString(8);
            Orgname = newcursor.getString(10);

            text_vaccine.setText(id+"\t"+date+" \t"+name+"\t"+phone+"\t"+gender+"\t"+status+"\t "+Orgname+"\n");
        }
    }
}