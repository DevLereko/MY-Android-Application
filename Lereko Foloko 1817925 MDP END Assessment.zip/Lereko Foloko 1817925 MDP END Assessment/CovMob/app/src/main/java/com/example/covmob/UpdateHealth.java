package com.example.covmob;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateHealth extends AppCompatActivity {
    EditText organization_id, organization_name, organization_email,organization_contact, physical_address, postal_code,
            no_of_employees, health_password;
    Button search_Org_daily, btn_update_org, btn_delete_org;
    public static String orgID;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_health);

        organization_id = (EditText) findViewById(R.id.organization_id);
        organization_name = (EditText) findViewById(R.id.organization_name);
        organization_email = (EditText) findViewById(R.id.organization_email);
        organization_contact = (EditText) findViewById(R.id.organization_contact);
        no_of_employees = (EditText) findViewById(R.id.no_of_employees);
        health_password = (EditText) findViewById(R.id.health_password);
        final DBHelper Databases = new DBHelper(this);

        // when button update is clicked ----//
        btn_update_org = (Button) findViewById(R.id.btn_update_org);
        btn_update_org.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String org_id = organization_id.getText().toString();
                String org_name = organization_name.getText().toString();
                String org_email = organization_email.getText().toString();
                String org_phone = organization_contact.getText().toString();
                String employees = no_of_employees.getText().toString();
                String healthPass = health_password.getText().toString();

                boolean isUpdate = Databases.UpdateHealth(org_id, org_name, org_email, org_phone, employees, healthPass);
                if (isUpdate==true) {
                    Toast.makeText(UpdateHealth.this, "Records Updated successfully!", Toast.LENGTH_SHORT).show();
                }
                else
                    Toast.makeText(UpdateHealth.this, "Failed To Update Records!", Toast.LENGTH_SHORT).show();
                clearTexts();
            }
        });
        // when button delete is clicked -----------------------//
        btn_delete_org = (Button) findViewById(R.id.btn_delete_org);
        btn_delete_org.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String org = organization_id.getText().toString();
                Integer deleteRows = Databases.deleteHealth(org);
                if (deleteRows > 0)
                    Toast.makeText(UpdateHealth.this, "Data Successfully Deleted!", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(UpdateHealth.this, "Failed to Delete Data!", Toast.LENGTH_SHORT).show();
                clearTexts();
            }
        });
        // when button search is clicked -----------------//
        search_Org_daily = (Button) findViewById(R.id.search_Org_daily);
        search_Org_daily.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                orgID = organization_id.getText().toString();
                getOrganization();
            }
        });

    }
    // clearfields after delete or update
    private void clearTexts() {
        organization_id.setText(null);
        organization_name.setText(null);
        organization_email.setText(null);
        organization_contact.setText(null);
        no_of_employees.setText(null);
        health_password.setText(null);
    }

    // when search button is clicked -----------------//
    private void getOrganization() {
        orgID = organization_id.getText().toString();
        DBHelper database = new DBHelper(this);

        String name = null, email = null, contact = null, employees = null, password = null;

        Cursor cursor = database.getHealthDetails(orgID);
        cursor.moveToNext();
        if (cursor.getCount() <= 0)
        {
            Toast.makeText(this, "organization Not Registered!", Toast.LENGTH_SHORT).show();
        }
        else
        {
            name = cursor.getString(1);
            email = cursor.getString(2);
            contact = cursor.getString(3);
            employees = cursor.getString(6);
            password = cursor.getString(8);

            organization_name.setText(name);
            organization_email.setText(email);
            organization_contact.setText(contact);
            no_of_employees.setText(employees);
            health_password.setText(password);
        }
    }
}