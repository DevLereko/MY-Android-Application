package com.example.covmob;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.regex.Pattern;

public class NonHealth extends AppCompatActivity {
    private static final Pattern PASSWORD_PATTERN =
            Pattern.compile("^" +
                    "(?=.*[0-9])" +        //at least 1 number
                    "(?=.*[a-z])" +        //at least 1 lowercase character
                    "(?=.*[A-Z])" +        //at least 1 uppercase character
                    "(?=.*[@#$%^&+=])" +   //at least 1 special character
                    "(?=.*[\\S+$])" +      //no white spaces
                    ".{8,}" +              //at least 8 characters
                    "$");
    Spinner non_health_org_type;
    String[] type = {"Private", "Public","Educational" ,"NGO"};
    Button non_org_register;
    TextView text_non_login;
    EditText non_health_org_id, non_health_org_name, non_health_org_email, non_health_contact, non_health_org_address,
            non_health_org_code, non_health_employees, non_health_password;

    DBHelper ThisDatabase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_non_health);

        non_health_org_type = (Spinner) findViewById(R.id.non_health_org_type);

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(NonHealth.this, android.R.layout.simple_spinner_item,type);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        non_health_org_type.setAdapter(arrayAdapter);

        non_health_org_id = (EditText) findViewById(R.id.non_health_org_id);
        non_health_org_name = (EditText) findViewById(R.id.non_health_org_name);
        non_health_org_email = (EditText) findViewById(R.id.non_health_org_email);
        non_health_contact = (EditText) findViewById(R.id.non_health_contact);
        non_health_org_address = (EditText) findViewById(R.id.non_health_org_address);
        non_health_org_code = (EditText) findViewById(R.id.non_health_org_code);
        non_health_employees = (EditText) findViewById(R.id.non_health_employees);
        non_health_password = (EditText) findViewById(R.id.non_health_password);
        final  DBHelper ThisDatabase = new DBHelper(this);

        //--------------------on Click of register button -------------------//
        non_org_register = (Button) findViewById(R.id.non_org_register);
        non_org_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //-----------------variable declaration and assignments --------------//
                String healthId = non_health_org_id.getText().toString();
                String healthName = non_health_org_name.getText().toString();
                String healthEmail = non_health_org_email.getText().toString();
                String healthContact = non_health_contact.getText().toString();
                String healthAddress = non_health_org_address.getText().toString();
                String healthCode = non_health_org_code.getText().toString();
                String healthEmployees = non_health_employees.getText().toString();
                String healthType = non_health_org_type.getSelectedItem().toString();
                String password = non_health_password.getText().toString();

                if (healthId.isEmpty()||healthName.isEmpty()||healthEmail.isEmpty()||healthContact.isEmpty()||healthAddress.isEmpty()||healthCode.isEmpty()
                ||healthEmployees.isEmpty()||password.isEmpty())
                    Toast.makeText(NonHealth.this, "These Fields cannot be empty!", Toast.LENGTH_SHORT).show();
                else {
                    Boolean checkId = ThisDatabase.checkNonId(healthId);
                    if (checkId==false)
                    {
                        Boolean insertDetails = ThisDatabase.InsertNonHealth(healthId, healthName, healthEmail, healthContact, healthAddress, healthCode,
                                healthEmployees, healthType, password);
                        if (insertDetails==true) {
                            Toast.makeText(NonHealth.this, "Successfully Registered Non Health Organization!", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), NonHealthHome.class);
                            startActivity(intent);
                        }
                        else
                            Toast.makeText(NonHealth.this, "Failed to register!", Toast.LENGTH_SHORT).show();
                    }
                    else
                        Toast.makeText(NonHealth.this, "Organization Already Exist!, Consider changing ID!", Toast.LENGTH_SHORT).show();
                }
                validateId();
                validateName();
                validateEmail ();
                validateContact();
                validateAddress();
                validatePostal_code();
                validateEmployees();
                validatePassword ();
                clearTexts ();
            }
        });
        // when login text
        text_non_login = (TextView) findViewById(R.id.text_non_login);
        text_non_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
            }
        });
    }
    //--------------------fields validation -------------------//
    //------------------------id validation ---------------------//
    public boolean validateId() {
        String inputId = non_health_org_id.getText().toString().trim();
        if (inputId.isEmpty()) {
            non_health_org_id.setError("ID cannot be empty!");
            return false;
        } else
            non_health_org_id.setError(null);
        return true;
    }
    // -------------------name validation -------------//
    public boolean validateName() {
        String inputname = non_health_org_name.getText().toString().trim();
        if (inputname.isEmpty()) {
            non_health_org_name.setError("organization name cannot be empty!");
            return false;
        } else
            non_health_org_name.setError(null);
        return true;
    }
    // ------------------------email validation ------------//
    public boolean validateEmail () {
        String inputemail = non_health_org_email.getText().toString().trim();
        if (inputemail.isEmpty()) {
            non_health_org_email.setError("email address cannot be empty!");
            return false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(inputemail).matches()) {
            non_health_org_email.setError("Please Enter A Valid Email Address!");
            return false;
        } else
            non_health_org_email.setError(null);
        return true;
    }
    // ------------------------validating contact
    public boolean validateContact() {
        String inputcontact = non_health_contact.getText().toString().trim();
        if (inputcontact.isEmpty()) {
            non_health_contact.setError("contact cannot be empty!");
            return false;
        } else
            non_health_contact.setError(null);
        return true;
    }
    // ---------------validate physical Address
    public boolean validateAddress() {
        String inputAddress = non_health_org_address.getText().toString().trim();
        if (inputAddress.isEmpty()) {
            non_health_org_address.setError("physical address cannot be empty!");
            return false;
        } else
            non_health_org_address.setError(null);
        return true;
    }
    //-----------------validating postal code
    public boolean validatePostal_code() {
        String inputcode = non_health_org_code.getText().toString().trim();
        if (inputcode.isEmpty()) {
            non_health_org_code.setError("postal code cannot be empty!");
            return false;
        } else
            non_health_org_code.setError(null);
        return true;
    }
    // ------------validate number of employees
    public boolean validateEmployees() {
        String inputnoEmployees = non_health_employees.getText().toString().trim();
        if (inputnoEmployees.isEmpty()) {
            non_health_employees.setError("Number of Employees cannot be empty!");
            return false;
        } else
            non_health_employees.setError(null);
        return true;
    }
    //-----------------password validation ----------------------//
    public boolean validatePassword () {
        String inputpass = non_health_password.getText().toString().trim();
        if (inputpass.isEmpty()) {
            non_health_password.setError("Password cannot be empty!");
            return false;
        } else if (!PASSWORD_PATTERN.matcher(inputpass).matches()) {
            non_health_password.setError("Password Too weak, Set Strong Password!");
            return false;
        } else
            non_health_password.setError(null);
        return true;
    }
    //--------------------clearing fields after registration ------------//
    public void clearTexts () {
        non_health_org_id.setText(null);
        non_health_org_name.setText(null);
        non_health_org_email.setText(null);
        non_health_contact.setText(null);
        non_health_org_address.setText(null);
        non_health_org_code.setText(null);
        non_health_employees.setText(null);
        non_health_password.setText(null);
    }
}