package com.example.covmob;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

public class NonHealthHome extends AppCompatActivity {
    LinearLayout layout_add_citizens, layout_activities, layout_update_nons, layout_users;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_non_health_home);

        // -----------------when layout add citizen is clicked
        layout_add_citizens = (LinearLayout) findViewById(R.id.layout_add_citizens);
        layout_add_citizens.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Citezens.class);
                startActivity(intent);
            }
        });
        //-----------------when layout activities is clicked ---------------//
        layout_activities = (LinearLayout) findViewById(R.id.layout_activities);
        layout_activities.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), DailyRecords.class);
                startActivity(intent);
            }
        });
        // when layout update non health is clicked
        layout_update_nons = (LinearLayout) findViewById(R.id.layout_update_nons);
        layout_update_nons.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), UpdateNonHealth.class);
                startActivity(intent);
            }
        });
        //----------------when Layout view users is clicked ---//
        layout_users = (LinearLayout) findViewById(R.id.layout_users);
        layout_users.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ViewMyEmployees.class);
                startActivity(intent);
            }
        });
    }
}