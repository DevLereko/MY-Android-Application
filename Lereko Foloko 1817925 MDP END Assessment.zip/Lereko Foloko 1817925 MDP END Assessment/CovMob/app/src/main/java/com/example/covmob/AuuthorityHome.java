package com.example.covmob;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Layout;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

public class AuuthorityHome extends AppCompatActivity {
    LinearLayout layout_add_admin, layout_view_users,layout_update_user, layout_update_health, layout_update_non, layout_health_org,
            layout_non_health, layout_reports, add_layout_client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auuthority_home);

        //-------------------when layout add admin is clicked ---------------//
        layout_add_admin = (LinearLayout) findViewById(R.id.layout_add_admin);
        layout_add_admin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Authority.class);
                startActivity(intent);
            }
        });
        //when layout update citizen is pressed
        layout_update_user = (LinearLayout) findViewById(R.id.layout_update_user);
        layout_update_user.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), DailyRecords.class);
                startActivity(intent);
            }
        });
        // when layout update health is pressed
        layout_update_health = (LinearLayout) findViewById(R.id.layout_update_health);
        layout_update_health.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), UpdateHealth.class);
                startActivity(intent);
            }
        });
        //when layout update non health is pressed
        layout_update_non = (LinearLayout) findViewById(R.id.layout_update_non);
        layout_update_non.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), UpdateNonHealth.class);
                startActivity(intent);
            }
        });
        //-------------------------when layout health organization is clicked -----//
        layout_health_org = (LinearLayout) findViewById(R.id.layout_health_org);
        layout_health_org.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),HealthRegister.class);
                startActivity(intent);
            }
        });
        //----------------------when Layout non health organization is clicked ---------//
        layout_non_health = (LinearLayout) findViewById(R.id.layout_non_health);
        layout_non_health.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), NonHealth.class);
                startActivity(intent);
            }
        });
        //- ---------------------When layout manage Reports is clicked --------------//
        layout_reports = (LinearLayout) findViewById(R.id.layout_reports);
        layout_reports.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Reports.class);
                startActivity(intent);
            }
        });
        // ------------------------when layout add citizen is clicked ------------//
        add_layout_client = (LinearLayout) findViewById(R.id.add_layout_client);
        add_layout_client.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Citezens.class);
                startActivity(intent);
            }
        });
        //-----------------------when layout view users is clicked ----------------//
        layout_view_users = (LinearLayout) findViewById(R.id.layout_view_users);
        layout_view_users.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ViewAllUsers.class);
                startActivity(intent);
            }
        });
    }
}