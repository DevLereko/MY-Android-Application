package com.example.covmob;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ViewAllUsers extends AppCompatActivity {
    Button search_personnel, view_all_health, view_all_non, view_all_user;
    EditText view_my_personnel;
    TextView text_display_users;

    public static String namesCitizen;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_all_users);

        view_my_personnel = (EditText) findViewById(R.id.view_my_personnel);

        text_display_users = (TextView) findViewById(R.id.text_display_users);

        // when button search for citizen is clicked
        search_personnel = (Button) findViewById(R.id.search_personnel);
        search_personnel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                namesCitizen = view_my_personnel.getText().toString();
                getCitizenSearched();
            }
        });
        // when button view all health is clicked
        view_all_health = (Button) findViewById(R.id.view_all_health);
        view_all_health.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getAllHealth();
            }
        });
        // when button view all non health is clicked
        view_all_non = (Button) findViewById(R.id.view_all_non);
        view_all_non.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getAllNonHealth();
            }
        });
        // when button view all clients is clicked
        view_all_user = (Button) findViewById(R.id.view_all_user);
        view_all_user.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getAllCitizens();
            }
        });
    }
//get searched citizen id
    private void getCitizenSearched() {
        namesCitizen = view_my_personnel.getText().toString();
        DBHelper DataBase = new DBHelper(this);

        String id = null, name = null, email = null, phone = null, origin = null, gender = null, Orgname = null;

        Cursor newcursor = DataBase.getCitizenD(namesCitizen);

        newcursor.moveToNext();
        if (newcursor.getCount() <=0 )
        {
            Toast.makeText(this, "There is Nothing to display!", Toast.LENGTH_SHORT).show();
        }
        else
        {
            id = newcursor.getString(0);
            name = newcursor.getString(2);
            email = newcursor.getString(3);
            phone = newcursor.getString(4);
            origin = newcursor.getString(6);
            gender = newcursor.getString(7);
            Orgname = newcursor.getString(9);

            text_display_users.setText(id+"\t"+name+" \t"+email+"\t"+phone+"\t"+origin+"\t "+gender+"\t"+Orgname+"\n");
        }
    }
//get all registered health organizations
    private void getAllHealth() {
        DBHelper DataBase = new DBHelper(this);

        String id = null, name = null, email = null, phone = null, address = null, code = null, no = null;

        Cursor newcursor = DataBase.getAllHealth();

        newcursor.moveToNext();
        if (newcursor.getCount() <=0 )
        {
            Toast.makeText(this, "There is Nothing to display!", Toast.LENGTH_SHORT).show();
        }
        else
        {
            id = newcursor.getString(0);
            name = newcursor.getString(1);
            email = newcursor.getString(2);
            phone = newcursor.getString(3);
            address = newcursor.getString(4);
            code = newcursor.getString(5);
            no = newcursor.getString(6);

            text_display_users.setText(id+"\t"+name+" \t"+email+"\t"+phone+"\t"+address+"\t "+code+"\t"+no+"\n");
        }
    }
// get all non health registered organizations
    private void getAllNonHealth() {
        DBHelper DataBase = new DBHelper(this);

        String id = null, name = null, email = null, phone = null, address = null, code = null, no = null;

        Cursor newcursor = DataBase.getAllNonHealth();

        newcursor.moveToNext();
        if (newcursor.getCount() <=0 )
        {
            Toast.makeText(this, "There is Nothing to display!", Toast.LENGTH_SHORT).show();
        }
        else
        {
            id = newcursor.getString(0);
            name = newcursor.getString(1);
            email = newcursor.getString(2);
            phone = newcursor.getString(3);
            address = newcursor.getString(4);
            code = newcursor.getString(5);
            no = newcursor.getString(6);

            text_display_users.setText(id+"\t"+name+" \t"+email+"\t"+phone+"\t"+address+"\t "+code+"\t"+no+"\n");
        }
    }
//get all registered citizens
    private void getAllCitizens() {
        DBHelper DataBase = new DBHelper(this);

        String id = null, name = null, email = null, phone = null, origin = null, gender = null, Orgname = null;

        Cursor newcursor = DataBase.getAllCitizens();

        newcursor.moveToNext();
        if (newcursor.getCount() <=0 )
        {
            Toast.makeText(this, "There is Nothing to display!", Toast.LENGTH_SHORT).show();
        }
        else
        {
            id = newcursor.getString(0);
            name = newcursor.getString(1);
            email = newcursor.getString(2);
            phone = newcursor.getString(3);
            origin = newcursor.getString(5);
            gender = newcursor.getString(6);
            Orgname = newcursor.getString(8);

            text_display_users.setText(id+"\t"+name+" \t"+email+"\t"+phone+"\t"+origin+"\t "+gender+"\t"+Orgname+"\n");
        }
    }
}