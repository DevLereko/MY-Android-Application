package com.example.covmob;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Pattern;

public class Authority extends AppCompatActivity {
    EditText auth_email, auth_name, auth_phone, auth_pass;
    Button btn_auth_register, btn_auth_signin;
    DBHelper MyDatabase;

    private static final Pattern PASSWORD_PATTERN =
            Pattern.compile("^" +
                    "(?=.*[0-9])" +        //at least 1 number
                    "(?=.*[a-z])" +        //at least 1 lowercase character
                    "(?=.*[A-Z])" +        //at least 1 uppercase character
                    "(?=.*[@#$%^&+=])" +   //at least 1 special character
                    "(?=.*[\\S+$])" +      //no white spaces
                    ".{8,}" +              //at least 8 characters
                    "$");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_authority);

        auth_email = (EditText) findViewById(R.id.auth_email);
        auth_name = (EditText) findViewById(R.id.auth_name);
        auth_phone = (EditText) findViewById(R.id.auth_phone);
        auth_pass = (EditText) findViewById(R.id.auth_pass);
        final DBHelper MyDatabase = new DBHelper(this);

        // -----------------------when button Register is clicked ---------------//
        btn_auth_register = (Button) findViewById(R.id.btn_auth_register);
        btn_auth_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //-----------------Assigning values ---------------//
                String email = auth_email.getText().toString();
                String name = auth_name.getText().toString();
                String phone = auth_phone.getText().toString();
                String pass = auth_pass.getText().toString();

                if (email.isEmpty()||name.isEmpty()||phone.isEmpty()||pass.isEmpty())
                    Toast.makeText(Authority.this, "Please Enter All Fields!", Toast.LENGTH_SHORT).show();
                else {
                    //---------------check is user already exists-------------//
                    Boolean checkEmail = MyDatabase.checkUserEmail(email);
                    if (checkEmail==false){
                        //------------------inserting to the database ----------------//
                        Boolean isInserted = MyDatabase.InsertAuthority(email, name, phone, pass);
                        if (isInserted==true) {
                            Toast.makeText(Authority.this, "Successfully Registered!", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                            startActivity(intent);
                        } else
                            Toast.makeText(Authority.this, " Failed to Register!", Toast.LENGTH_SHORT).show();
                    } else
                        Toast.makeText(Authority.this, "User Already Exists!", Toast.LENGTH_SHORT).show();
                }
                validateEmail();
                validateName();
                validatephone();
                validatePassword();
                clearFields ();
            }
        });
     }

     // ---------------------fields validation -----------//
     public boolean validateEmail () {
         String inputemail = auth_email.getText().toString().trim();
         if (inputemail.isEmpty()) {
             auth_email.setError("email address cannot be empty!");
             return false;
         } else if (!Patterns.EMAIL_ADDRESS.matcher(inputemail).matches()) {
             auth_email.setError("Please Enter A Valid Email Address!");
             return false;
         } else
             auth_email.setError(null);
         return true;
     }
     //name validation
     public boolean validateName() {
         String inputphone = auth_name.getText().toString().trim();
         if (inputphone.isEmpty()) {
             auth_name.setError("phone number cannot be empty!");
             return false;
         } else
             auth_name.setError(null);
         return true;
     }
    //validating phone number
    public boolean validatephone() {
        String inputphone = auth_phone.getText().toString().trim();
        if (inputphone.isEmpty()) {
            auth_phone.setError("phone number cannot be empty!");
            return false;
        } else
            auth_phone.setError(null);
        return true;
    }
    //validating password field
    public boolean validatePassword () {
        String inputpass = auth_pass.getText().toString().trim();
        if (inputpass.isEmpty()) {
            auth_pass.setError("Password cannot be empty!");
            return false;
        } else if (!PASSWORD_PATTERN.matcher(inputpass).matches()) {
            auth_pass.setError("Password Too weak, Set Strong Password!");
            return false;
        } else
            auth_pass.setError(null);
        return true;
    }
     //-------------clearing fields after successful insertion -------------//
    public void clearFields () {
        auth_email.setText(null);
        auth_name.setText(null);
        auth_phone.setText(null);
        auth_pass.setText(null);
    }
}