package com.example.covmob;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateNonHealth extends AppCompatActivity {
    Button search_non_daily, btn_update_non_org, btn_delete_non_org;

    EditText non_health_org_id, non_health_org_name, non_health_org_email, non_health_contact, non_health_employees, non_health_password;
    public static String OrganID;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_non_health);


        non_health_org_id = (EditText) findViewById(R.id.non_health_org_id);
        non_health_org_name = (EditText) findViewById(R.id.non_health_org_name);
        non_health_org_email = (EditText) findViewById(R.id.non_health_org_email);
        non_health_contact = (EditText) findViewById(R.id.non_health_contact);
        non_health_employees = (EditText) findViewById(R.id.non_health_employees);
        non_health_password = (EditText) findViewById(R.id.non_health_password);
        final DBHelper TheDatabase = new DBHelper(this);
        // when search button is pressed
        search_non_daily = (Button) findViewById(R.id.search_non_daily);
        search_non_daily.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OrganID = non_health_org_id.getText().toString();
                searchOrg();
            }
        });
        // when update button is pressed
        btn_update_non_org = (Button) findViewById(R.id.btn_update_non_org);
        btn_update_non_org.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String healthId = non_health_org_id.getText().toString();
                String healthName = non_health_org_name.getText().toString();
                String healthEmail = non_health_org_email.getText().toString();
                String healthContact = non_health_contact.getText().toString();
                String healthEmployees = non_health_employees.getText().toString();
                String password = non_health_password.getText().toString();

                boolean isUpdated = TheDatabase.UpdateNonOrg(healthId, healthName, healthEmail, healthContact, healthEmployees, password);
                if (isUpdated==true) {
                    Toast.makeText(UpdateNonHealth.this, "Updated Successfully!", Toast.LENGTH_SHORT).show();
                }
                else
                    Toast.makeText(UpdateNonHealth.this, "Failed to update!", Toast.LENGTH_SHORT).show();
                clearTexts();
            }
        });
        //when button delete is pressed
        btn_delete_non_org = (Button) findViewById(R.id.btn_delete_non_org);
        btn_delete_non_org.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OrganID = non_health_org_id.getText().toString();
                Integer deleteRows = TheDatabase.deleteNoN(OrganID);
                if (deleteRows > 0)
                    Toast.makeText(UpdateNonHealth.this, "Data Successfully Deleted!", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(UpdateNonHealth.this, "Failed to Delete Data!", Toast.LENGTH_SHORT).show();
                clearTexts();
            }
        });
    }
    // clearing fields after upadte
    private void clearTexts() {
        non_health_org_id.setText(null);
        non_health_org_name.setText(null);
        non_health_org_email.setText(null);
        non_health_contact.setText(null);
        non_health_employees.setText(null);
        non_health_password.setText(null);
    }

    // search method for retrieving records
    private void searchOrg() {
        OrganID  = non_health_org_id.getText().toString();
        DBHelper database = new DBHelper(this);

        String name = null, email = null, contact = null, employees = null, password = null;

        Cursor cursor = database.getNonHealthDetails(OrganID);
        cursor.moveToNext();
        if (cursor.getCount() <= 0)
        {
            Toast.makeText(this, "Organization Not Registered!", Toast.LENGTH_SHORT).show();
        }
        else
        {
            name = cursor.getString(1);
            email = cursor.getString(2);
            contact = cursor.getString(3);
            employees = cursor.getString(6);
            password = cursor.getString(8);

            non_health_org_name.setText(name);
            non_health_org_email.setText(email);
            non_health_contact.setText(contact);
            non_health_employees.setText(employees);
            non_health_password.setText(password);
        }
    }

}