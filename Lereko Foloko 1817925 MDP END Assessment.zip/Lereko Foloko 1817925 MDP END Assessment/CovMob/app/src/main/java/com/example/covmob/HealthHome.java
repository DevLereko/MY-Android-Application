package com.example.covmob;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

public class HealthHome extends AppCompatActivity {
    LinearLayout layout_add_citizen, layout_activity, layout_update_healths, layout_vaccination, layout_all_users;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_health_home);

        //---------when add citizen layout is clicked
        layout_add_citizen = (LinearLayout)  findViewById(R.id.layout_add_citizen);
        layout_add_citizen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Citezens.class);
                startActivity(intent);
            }
        });
        //------when layout activity is clicked --------
        layout_activity = (LinearLayout) findViewById(R.id.layout_activity);
        layout_activity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), DailyRecords.class);
                startActivity(intent);
            }
        });
        // when update health organization is clicked
        layout_update_healths = (LinearLayout) findViewById(R.id.layout_update_healths);
        layout_update_healths.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), UpdateHealth.class);
                startActivity(intent);
            }
        });
        //---------------when record vaccination is clicked ---------
        layout_vaccination = (LinearLayout) findViewById(R.id.layout_vaccination);
        layout_vaccination.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),vaccination.class);
                startActivity(intent);
            }
        });
        // ------------------------when view all users layout is clicked
        layout_all_users = (LinearLayout) findViewById(R.id.layout_all_users);
        layout_all_users.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ViewMyEmployees.class);
                startActivity(intent);
            }
        });
    }

}