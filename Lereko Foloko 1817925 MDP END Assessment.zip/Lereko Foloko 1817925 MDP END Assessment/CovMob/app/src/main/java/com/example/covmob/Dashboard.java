package com.example.covmob;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class Dashboard extends AppCompatActivity {
    LinearLayout layout_register, layout_login, layout_contact, layout_developer;

    ImageView img_slider;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        img_slider = (ImageView) findViewById(R.id.img_slider);
        AnimationDrawable animationDrawable = (AnimationDrawable) img_slider.getDrawable();
        animationDrawable.start();

        //when register layout is clicked
        layout_register = (LinearLayout) findViewById(R.id.layout_register);
        layout_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Citezens.class);
                startActivity(intent);
            }
        });
        //when login layout is clicked
        layout_login = (LinearLayout) findViewById(R.id.layout_login);
        layout_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
            }
        });
        //when contact us layout is clicked
        layout_contact = (LinearLayout) findViewById(R.id.layout_contact);
        layout_contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),ContactUs.class);
                startActivity(i);
            }
        });
        //when about developer layout is clicked
        layout_developer = (LinearLayout) findViewById(R.id.layout_developer);
        layout_developer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),AboutUs.class);
                startActivity(intent);
            }
        });
    }
}