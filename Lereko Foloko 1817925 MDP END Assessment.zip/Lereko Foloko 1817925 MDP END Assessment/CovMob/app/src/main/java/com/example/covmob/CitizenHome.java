package com.example.covmob;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class CitizenHome extends AppCompatActivity {
    LinearLayout layout_my_details, layout_my_activity;
    ImageView img_sliders;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_citizen_home);

        img_sliders = (ImageView) findViewById(R.id.img_sliders);
        AnimationDrawable animationDrawable = (AnimationDrawable) img_sliders.getDrawable();
        animationDrawable.start();

        // -------------------when layout view my details is clicked
        layout_my_details = (LinearLayout) findViewById(R.id.layout_my_details);
        layout_my_details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), CitizenDetails.class);
                startActivity(intent);
            }
        });
        //--------------------when layout my activity is clicked
        layout_my_activity = (LinearLayout) findViewById(R.id.layout_my_activity);
        layout_my_activity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), DailyRecords.class);
                startActivity(intent);
            }
        });
    }
}