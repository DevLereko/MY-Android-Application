package com.example.covmob;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.net.IDN;
import java.util.Calendar;

public class vaccination extends AppCompatActivity {

    Spinner place_of_origin, vacc_status;
    String[] place = {"Maseru", "Botha-Bothe", "Leribe", "Berea", "Mafeteng", "Mohale's Hoek",
            "Mokhotlong", "Thaba-Tseka", "Qacha's Nek", "Quthing"};
    String[] status = {"Not_Vaccinated", "Vaccinated"};

    TextView citizen_vacc_register;
    EditText citizen_vacc_id, vacc_id, vacc_date, vacc_name, citizen_tem, citizen_vacc_phone, reason, org_vacc_name, org_vacc_id;
    Spinner rbn_vacc_gender;
    Button search_Citizen, btn_submit, btn_view_data;
    public static String citizenId;
    String[] genserr = {"Male", "Female"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vaccination);

        rbn_vacc_gender = (Spinner) findViewById(R.id.rbn_vacc_gender);

        ArrayAdapter<String> arrayAdaptergender = new ArrayAdapter<>(vaccination.this, android.R.layout.simple_spinner_item,genserr);
        arrayAdaptergender.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        rbn_vacc_gender.setAdapter(arrayAdaptergender);

        // ------------------Allowing spinner to take district selected ------------//
        place_of_origin = (Spinner) findViewById(R.id.place_of_origin);

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(vaccination.this, android.R.layout.simple_spinner_item,place);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        place_of_origin.setAdapter(arrayAdapter);

        //--------------------Updating vaccination status-----------------------//
        vacc_status = (Spinner) findViewById(R.id.vacc_status);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(vaccination.this, android.R.layout.simple_spinner_item,status);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        vacc_status.setAdapter(adapter);

        citizen_vacc_id = (EditText) findViewById(R.id.citizen_vacc_id);
        vacc_id = (EditText) findViewById(R.id.vacc_id);
        vacc_date = (EditText) findViewById(R.id.vacc_date);
        vacc_name = (EditText) findViewById(R.id.vacc_name);
        citizen_tem = (EditText) findViewById(R.id.citizen_tem);
        citizen_vacc_phone = (EditText) findViewById(R.id.citizen_vacc_phone);
        reason = (EditText) findViewById(R.id.reason);
        org_vacc_name = (EditText) findViewById(R.id.org_vacc_name);
        org_vacc_id = (EditText) findViewById(R.id.org_vacc_id);
        final DBHelper dbHelper = new DBHelper(this);

        // when Search button is pressed
        search_Citizen = (Button) findViewById(R.id.search_Citizen);
        search_Citizen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                citizenId = citizen_vacc_id.getText().toString();
                searchCitizenID();
            }
        });
        // when save button is clicked
        btn_submit = (Button) findViewById(R.id.btn_submit);
        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String citizenIDC = citizen_vacc_id.getText().toString();
                String Id = vacc_id.getText().toString();
                String vaccDate = vacc_date.getText().toString();
                String Citizen = vacc_name.getText().toString();
                String temp = citizen_tem.getText().toString();
                String phone = citizen_vacc_phone.getText().toString();
                String gender = rbn_vacc_gender.getSelectedItem().toString();
                String district = place_of_origin.getSelectedItem().toString();
                String status = vacc_status.getSelectedItem().toString();
                String Reason = reason.getText().toString();
                String orgName = org_vacc_name.getText().toString();
                String orgID = org_vacc_id.getText().toString();

                if (citizenIDC.isEmpty()||Id.isEmpty()||vaccDate.isEmpty()||Citizen.isEmpty()||temp.isEmpty()||phone.isEmpty())
                    Toast.makeText(vaccination.this, "Please Fill These Fields!", Toast.LENGTH_SHORT).show();
                else {
                    Boolean InsertVacc = dbHelper.InsertVaccination(citizenIDC, Id, vaccDate, Citizen, temp, phone, gender, district,
                            status, Reason, orgName, orgID);
                    if (InsertVacc==true) {
                        Toast.makeText(vaccination.this, "Success, Vaccination Recorded!", Toast.LENGTH_SHORT).show();
                    }
                    else
                        Toast.makeText(vaccination.this, "Failed To Record Vaccination!", Toast.LENGTH_SHORT).show();
                }
                validateID();
                validateVaccID();
                validatedate();
                validatename();
                validateTemp();
                validatePhone();
                ClearFields ();
            }
        });
        // when button view is clicked
        btn_view_data = (Button) findViewById(R.id.btn_view_data);
        btn_view_data.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ViewAllVaccinated.class);
                startActivity(intent);
            }
        });
        // when text register is clicked ----------------//
        citizen_vacc_register = (TextView) findViewById(R.id.citizen_vacc_register);
        citizen_vacc_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Citezens.class);
                startActivity(intent);
            }
        });
    }

    private void ClearFields() {
        citizen_vacc_id.setText(null);
        vacc_id.setText(null);
        vacc_date.setText(null);
        vacc_name.setText(null);
        citizen_tem.setText(null);
        citizen_vacc_phone.setText(null);
        org_vacc_name.setText(null);
        org_vacc_id.setText(null);
    }

    // method for when search button is pressed
    private void searchCitizenID() {
        citizenId = citizen_vacc_id.getText().toString();

        DBHelper DBN = new DBHelper(this);
        String name = null, phone = null, tem = null, orgName = null, orgID = null;

        Cursor cursor = DBN.getCitizenID(citizenId);

        cursor.moveToNext();
        if (cursor.getCount() <= 0)
        {
            Toast.makeText(this, "Citizen Not registered Or ID is Incorrect!", Toast.LENGTH_SHORT).show();
        }
        else
            {
            name = cursor.getString(2);
            phone =cursor.getString(4);
            tem = cursor.getString(5);
            orgName = cursor.getString(9);
            orgID = cursor.getString(10);

            vacc_name.setText(name);
            citizen_vacc_phone.setText(phone);
            citizen_tem.setText(tem);
            org_vacc_name.setText(orgName);
            org_vacc_id.setText(orgID);
        }
    }

    //fields validation
    //validate citizen id
    public boolean validateID() {
        String inputid = citizen_vacc_id.getText().toString().trim();
        if (inputid.isEmpty()) {
            citizen_vacc_id.setError("Id cannot be empty!");
            return false;
        } else
            citizen_vacc_id.setError(null);
        return true;
    }
    //validate vaccinationID
    public boolean validateVaccID() {
        String inputid = vacc_id.getText().toString().trim();
        if (inputid.isEmpty()) {
            vacc_id.setError("Vaccination Id cannot be empty!");
            return false;
        } else
            vacc_id.setError(null);
        return true;
    }
    //validate date
    public boolean validatedate() {
        String inputname = vacc_date.getText().toString().trim();
        if (inputname.isEmpty()) {
            vacc_date.setError("Date cannot be empty!");
            return false;
        } else
            vacc_date.setError(null);
        return true;
    }
    //validate name
    public boolean validatename() {
        String inputname = vacc_name.getText().toString().trim();
        if (inputname.isEmpty()) {
            vacc_name.setError("name cannot be empty!");
            return false;
        } else
            vacc_name.setError(null);
        return true;
    }
    //validate temperature
    public boolean validateTemp() {
        String inputname = citizen_tem.getText().toString().trim();
        if (inputname.isEmpty()) {
            citizen_tem.setError("temperature cannot be empty!");
            return false;
        } else
            citizen_tem.setError(null);
        return true;
    }
    //validate temperature
    public boolean validatePhone() {
        String inputname = citizen_vacc_phone.getText().toString().trim();
        if (inputname.isEmpty()) {
            citizen_vacc_phone.setError("Phone cannot be empty!");
            return false;
        } else
            citizen_vacc_phone.setError(null);
        return true;
    }


}