package com.example.covmob;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.regex.Pattern;

public class HealthRegister extends AppCompatActivity {
    private static final Pattern PASSWORD_PATTERN =
            Pattern.compile("^" +
                    "(?=.*[0-9])" +        //at least 1 number
                    "(?=.*[a-z])" +        //at least 1 lowercase character
                    "(?=.*[A-Z])" +        //at least 1 uppercase character
                    "(?=.*[@#$%^&+=])" +   //at least 1 special character
                    "(?=.*[\\S+$])" +      //no white spaces
                    ".{8,}" +              //at least 8 characters
                    "$");

    EditText organization_id, organization_name, organization_email,organization_contact, physical_address, postal_code,
            no_of_employees, health_password;
    DBHelper Database;
    TextView health_text_login;
    Button health_register;
    Spinner organization_type;
    String[] typeOf = {"Private", "Public", "NGO"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_health_register);

        organization_type = (Spinner) findViewById(R.id.organization_type);

        ArrayAdapter<String> myadapter = new ArrayAdapter<String>(HealthRegister.this, android.R.layout.simple_spinner_item,typeOf);
        myadapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        organization_type.setAdapter(myadapter);

        organization_id = (EditText) findViewById(R.id.organization_id);
        organization_name = (EditText) findViewById(R.id.organization_name);
        organization_email = (EditText) findViewById(R.id.organization_email);
        organization_contact = (EditText) findViewById(R.id.organization_contact);
        physical_address = (EditText) findViewById(R.id.physical_address);
        postal_code = (EditText) findViewById(R.id.postal_code);
        no_of_employees = (EditText) findViewById(R.id.no_of_employees);
        health_password = (EditText) findViewById(R.id.health_password);
        final DBHelper Database = new DBHelper(this);

        //-----------------when register button is clicked-----------//
        health_register = (Button) findViewById(R.id.health_register);
        health_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //------------Variable Declarations -----------------//
                String org_id = organization_id.getText().toString();
                String org_name = organization_name.getText().toString();
                String org_email = organization_email.getText().toString();
                String org_phone = organization_contact.getText().toString();
                String address = physical_address.getText().toString();
                String post_code = postal_code.getText().toString();
                String employees = no_of_employees.getText().toString();
                String typeOf = organization_type.getSelectedItem().toString();
                String healthPass = health_password.getText().toString();

                if (org_id.isEmpty()||org_name.isEmpty()||org_email.isEmpty()||org_phone.isEmpty()||address.isEmpty()||post_code.isEmpty()
                        ||employees.isEmpty()||healthPass.isEmpty())
                    Toast.makeText(HealthRegister.this, "Enter All Fields Please!", Toast.LENGTH_SHORT).show();
                else {
                    Boolean checkOrganizationID = Database.checkOrganization(org_id);
                    if (checkOrganizationID==false)
                    {
                        Boolean registered = Database.InsertHealth(org_id, org_name, org_email, org_phone, address, post_code, employees,
                                typeOf, healthPass);
                        if (registered==true) {
                            Toast.makeText(HealthRegister.this, "Successfully Registered Organization!", Toast.LENGTH_SHORT).show();
                        }
                        else
                            Toast.makeText(HealthRegister.this, "Failed to register Organization!", Toast.LENGTH_SHORT).show();
                    }
                    else
                        Toast.makeText(HealthRegister.this, "Organization Already Exists!", Toast.LENGTH_SHORT).show();
                }
                validateId();
                validateName();
                validateEmail ();
                validateContact();
                validateAddress();
                validatePostal_code();
                validateEmployees();
                validatePassword ();
                clearTexts ();
            }
        });
        // when text login
        health_text_login = (TextView) findViewById(R.id.health_text_login);
        health_text_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
            }
        });
    }

    //-----------------clearing fields after insertion-----------------//
    public void clearTexts () {
        organization_id.setText(null);
        organization_name.setText(null);
        organization_email.setText(null);
        organization_contact.setText(null);
        physical_address.setText(null);
        postal_code.setText(null);
        no_of_employees.setText(null);
        health_password.setText(null);
    }

    //--------------------fields validation -------------------//
    //------------------------id validation ---------------------//
    public boolean validateId() {
        String inputId = organization_id.getText().toString().trim();
        if (inputId.isEmpty()) {
            organization_id.setError("ID cannot be empty!");
            return false;
        } else
            organization_id.setError(null);
        return true;
    }
    // -------------------name validation -------------//
    public boolean validateName() {
        String inputname = organization_name.getText().toString().trim();
        if (inputname.isEmpty()) {
            organization_name.setError("organization name cannot be empty!");
            return false;
        } else
            organization_name.setError(null);
        return true;
    }
    // ------------------------email validation ------------//
    public boolean validateEmail () {
        String inputemail = organization_email.getText().toString().trim();
        if (inputemail.isEmpty()) {
            organization_email.setError("email address cannot be empty!");
            return false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(inputemail).matches()) {
            organization_email.setError("Please Enter A Valid Email Address!");
            return false;
        } else
            organization_email.setError(null);
        return true;
    }
    // ------------------------validating contact
    public boolean validateContact() {
        String inputcontact = organization_contact.getText().toString().trim();
        if (inputcontact.isEmpty()) {
            organization_contact.setError("contact cannot be empty!");
            return false;
        } else
            organization_contact.setError(null);
        return true;
    }
 // ---------------validate physical Address
    public boolean validateAddress() {
        String inputAddress = physical_address.getText().toString().trim();
        if (inputAddress.isEmpty()) {
            physical_address.setError("physical address cannot be empty!");
            return false;
        } else
            physical_address.setError(null);
        return true;
    }
    //-----------------validating postal code
    public boolean validatePostal_code() {
        String inputcode = postal_code.getText().toString().trim();
        if (inputcode.isEmpty()) {
            postal_code.setError("postal code cannot be empty!");
            return false;
        } else
            postal_code.setError(null);
        return true;
    }
    // ------------validate number of employees
    public boolean validateEmployees() {
        String inputnoEmployees = no_of_employees.getText().toString().trim();
        if (inputnoEmployees.isEmpty()) {
            no_of_employees.setError("Number of Employees cannot be empty!");
            return false;
        } else
            no_of_employees.setError(null);
        return true;
    }
    //validating passwords
    public boolean validatePassword () {
        String inputpass = health_password.getText().toString().trim();
        if (inputpass.isEmpty()) {
            health_password.setError("Password cannot be empty!");
            return false;
        } else if (!PASSWORD_PATTERN.matcher(inputpass).matches()) {
            health_password.setError("Password Too weak, Set Strong Password!");
            return false;
        } else
            health_password.setError(null);
        return true;
    }
}