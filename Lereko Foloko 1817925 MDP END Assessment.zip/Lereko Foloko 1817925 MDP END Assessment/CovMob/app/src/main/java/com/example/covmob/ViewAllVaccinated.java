package com.example.covmob;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class ViewAllVaccinated extends AppCompatActivity {
    Button not_vaccinated, vaccinated;
    TextView text_vaccination;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_all_vaccinated);

        text_vaccination = (TextView) findViewById(R.id.text_vaccination);


        final DBHelper dbHelper = new DBHelper(this);

        // when vaccinated button is clicked
        vaccinated = (Button) findViewById(R.id.vaccinated);
        vaccinated.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getVaccinated ();
            }
        });
        //when button not vaccinated is clicked
        not_vaccinated = (Button) findViewById(R.id.not_vaccinated);
        not_vaccinated.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getNotVaccinated (); }});
    }
    // get all vaccinated
    public void getVaccinated () {

        DBHelper DataBase = new DBHelper(this);

        String id = null, date = null, name = null, phone = null, status = null, Orgname = null;

        Cursor newcursor = DataBase.getAllVaccinated();

        newcursor.moveToNext();
        if (newcursor.getCount() <=0 )
        {
            Toast.makeText(this, "There is Nothing to display!", Toast.LENGTH_SHORT).show();
        }
        else
        {
            id = newcursor.getString(0);
            date = newcursor.getString(2);
            name = newcursor.getString(3);
            phone = newcursor.getString(5);
            status = newcursor.getString(8);
            Orgname = newcursor.getString(10);

            text_vaccination.setText(id+"\t"+date+" \t"+name+"\t"+phone+"\t"+status+"\t "+Orgname);
        }
    }
    //get all not vaccinated and reasons
    public void getNotVaccinated () {

        DBHelper DataBase = new DBHelper(this);

        String id = null, date = null, name = null, phone = null, status = null, reason = null, Orgname = null;

        Cursor newcursor = DataBase.getAllNotVaccinated();

        newcursor.moveToNext();
        if (newcursor.getCount() <=0 )
        {
            Toast.makeText(this, "There is Nothing to display!", Toast.LENGTH_SHORT).show();
        }
        else
        {
            id = newcursor.getString(0);
            date = newcursor.getString(2);
            name = newcursor.getString(3);
            phone = newcursor.getString(5);
            status = newcursor.getString(8);
            reason = newcursor.getString(9);
            Orgname = newcursor.getString(10);

            text_vaccination.setText(id+"\t"+date+" \t"+name+"\t"+phone+"\t"+status+"\t "+reason+"\t"+Orgname);
        }
    }
}