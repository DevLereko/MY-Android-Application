package com.example.covmob;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.regex.Pattern;

public class Citezens extends AppCompatActivity {

    private static final Pattern PASSWORD_PATTERN =
            Pattern.compile("^" +
                    "(?=.*[0-9])" +        //at least 1 number
                    "(?=.*[a-z])" +        //at least 1 lowercase character
                    "(?=.*[A-Z])" +        //at least 1 uppercase character
                    "(?=.*[@#$%^&+=])" +   //at least 1 special character
                    "(?=.*[\\S+$])" +      //no white spaces
                    ".{8,}" +              //at least 8 characters
                    "$");

    EditText national_id, reg_date, citizen_name, citizen_email, citizen_phone, temp_citizen, citizen_password,
            citizen_organization_name, citizen_organization_id;
    Button search_org, citizen_register;
    TextView citizen_text_login;
    Spinner rbn_gender;
    Spinner citizen_origin;
    String[] gend = {"Male", "Female"};
    String[] district = {"Maseru", "Botha-Bothe", "Leribe", "Berea", "Mafeteng", "Mohale's Hoek",
            "Mokhotlong", "Thaba-Tseka", "Qacha's Nek", "Quthing"};

    public static String name ="";
    DBHelper  NewDatabase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_citezens);

        rbn_gender = (Spinner) findViewById(R.id.rbn_gender);

        ArrayAdapter<String> adaper = new ArrayAdapter<>(Citezens.this, android.R.layout.simple_spinner_item,gend);
        adaper.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        rbn_gender.setAdapter(adaper);

        citizen_origin = (Spinner) findViewById(R.id.citizen_origin);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(Citezens.this, android.R.layout.simple_spinner_item,district);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        citizen_origin.setAdapter(adapter);

        national_id = (EditText) findViewById(R.id.national_id);
        reg_date = (EditText) findViewById(R.id.reg_date);
        citizen_name = (EditText) findViewById(R.id.citizen_name);
        citizen_email = (EditText) findViewById(R.id.citizen_email);
        citizen_phone = (EditText) findViewById(R.id.citizen_phone);
        temp_citizen = (EditText) findViewById(R.id.temp_citizen);
        citizen_password = (EditText) findViewById(R.id.citizen_password);
        citizen_organization_name = (EditText) findViewById(R.id.citizen_organization_name);
        citizen_organization_id = (EditText) findViewById(R.id.citizen_organization_id);
        final DBHelper NewDatabase = new DBHelper(this);

        //--------------------When Search button is clicked -----------------//
        search_org = (Button) findViewById(R.id.search_org);
        search_org.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // ---------------------Search function --------------------------//
                name = citizen_organization_name.getText().toString();
                searchOrganization();
            }
        });
        //--------------------when register button is pressed -----------------//
        citizen_register = (Button) findViewById(R.id.citizen_register);
        citizen_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String nationalId = national_id.getText().toString();
                String date = reg_date.getText().toString();
                String Nameof = citizen_name.getText().toString();
                String emailCiti = citizen_email.getText().toString();
                String citiContact = citizen_phone.getText().toString();
                String citizenTemp = temp_citizen.getText().toString();
                String place = citizen_origin.getSelectedItem().toString();
                String gender = rbn_gender.getSelectedItem().toString();
                String passwd = citizen_password.getText().toString();
                String orgName = citizen_organization_name.getText().toString();
                String orgId = citizen_organization_id.getText().toString();

                if (nationalId.isEmpty()||date.isEmpty()||Nameof.isEmpty()||emailCiti.isEmpty()||citiContact.isEmpty()||place.isEmpty()||passwd.isEmpty())
                    Toast.makeText(Citezens.this, "These fields cannot be empty!", Toast.LENGTH_SHORT).show();
                else {
                    Boolean checkIdentity = NewDatabase.checkNationalID(nationalId);
                    if (checkIdentity==false){
                        Boolean isRegistered = NewDatabase.InsertCitizen(nationalId, date, Nameof, emailCiti, citiContact,
                                citizenTemp, place, gender, passwd, orgName, orgId);
                        if (isRegistered==true) {
                            Toast.makeText(Citezens.this, "Successfully Registered Citizen!", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(),LoginActivity.class);
                            startActivity(intent);
                        }
                        else
                            Toast.makeText(Citezens.this, "Failed to Register Citizen!", Toast.LENGTH_SHORT).show();
                    }
                    else
                        Toast.makeText(Citezens.this, "Citizen Already Exists!", Toast.LENGTH_SHORT).show();
                }
                validateId();
                validateDate ();
                validatename();
                validateEmail();
                validatephone();
                validateTEmperature();
                validatePassword();
                clearFields ();
            }
        });
        // -----------------when sign in text is clicked -----------//
        citizen_text_login = (TextView) findViewById(R.id.citizen_text_login);
        citizen_text_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
            }
        });
    }
    //---------------------search function -------------------//
    public void searchOrganization() {

        name = citizen_organization_name.getText().toString();

        DBHelper DB = new DBHelper(this);
        String id = null;
        Cursor orgID = DB.getSearchedID(name);

        orgID.moveToNext();
        if (orgID.getCount() <= 0 )
        {
            Toast.makeText(this, "Organization not Registered!", Toast.LENGTH_SHORT).show();
        }
        else
        {
            id = orgID.getString(0);
            citizen_organization_id.setText(id);
        }
    }
    //-------------------set fields to empty after insertion --------------//
    public void  clearFields () {
        national_id.setText(null);
        reg_date.setText(null);
        citizen_name.setText(null);
        citizen_email.setText(null);
        citizen_phone.setText(null);
        temp_citizen.setText(null);
        citizen_password.setText(null);
        citizen_organization_name.setText(null);
        citizen_organization_id.setText(null);
    }
    //------------------fields validation -------------------------//
    // -------------------------national id validation -------------//
    public boolean validateId() {
        String inputname = national_id.getText().toString().trim();
        if (inputname.isEmpty()) {
            national_id.setError("ID cannot be empty!");
            return false;
        } else
            national_id.setError(null);
        return true;
    }
    // validating date field
    public boolean validateDate (){
        String inputdate = reg_date.getText().toString().trim();
        if (inputdate.isEmpty()) {
            reg_date.setError("Date cannot be empty!");
            return false;
        } else
            reg_date.setError(null);
        return true;
    }
    //validating name
    public boolean validatename() {
        String inputname = citizen_name.getText().toString().trim();
        if (inputname.isEmpty()) {
            citizen_name.setError("name cannot be empty!");
            return false;
        } else
            citizen_name.setError(null);
        return true;
    }
    //----------------email validation -----------------------//
    public boolean validateEmail () {
        String inputemail = citizen_email.getText().toString().trim();
        if (inputemail.isEmpty()) {
            citizen_email.setError("email address cannot be empty!");
            return false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(inputemail).matches()) {
            citizen_email.setError("Please Enter A Valid Email Address!");
            return false;
        } else
            citizen_email.setError(null);
        return true;
    }
    //validating phone number
    public boolean validatephone() {
        String inputphone = citizen_phone.getText().toString().trim();
        if (inputphone.isEmpty()) {
            citizen_phone.setError("phone number cannot be empty!");
            return false;
        } else
            citizen_phone.setError(null);
        return true;
    }
    //validate temperature
    public boolean validateTEmperature() {
        String inputtemp = temp_citizen.getText().toString().trim();
        if (inputtemp.isEmpty()) {
            temp_citizen.setError("temperature number cannot be empty!");
            return false;
        } else
            temp_citizen.setError(null);
        return true;
    }
    //-----------------password validation ----------------------//
    public boolean validatePassword () {
        String inputpass = citizen_password.getText().toString().trim();
        if (inputpass.isEmpty()) {
            citizen_password.setError("Password cannot be empty!");
            return false;
        } else if (!PASSWORD_PATTERN.matcher(inputpass).matches()) {
            citizen_password.setError("Password Too weak, Set Strong Password!");
            return false;
        } else
            citizen_password.setError(null);
        return true;
    }

}
