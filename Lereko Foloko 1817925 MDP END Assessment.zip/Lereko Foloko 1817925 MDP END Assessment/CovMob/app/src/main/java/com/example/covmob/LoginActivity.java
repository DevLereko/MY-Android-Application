package com.example.covmob;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    Spinner user_type;
    String[] users = {"Authority", "Citizen", "Health_Organization", "Non_Health_Organization"};

    EditText login_email, login_password;
    Button btn_login;
    TextView btn_signup;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //----------------Selection of user type---------------//
        user_type = (Spinner) findViewById(R.id.user_type);

        ArrayAdapter<String> newlogin = new ArrayAdapter<>(LoginActivity.this, android.R.layout.simple_spinner_item,users);
        newlogin.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        user_type.setAdapter(newlogin);

        login_email = (EditText) findViewById(R.id.login_email);
        login_password = (EditText) findViewById(R.id.login_password);
        final DBHelper MyDB = new DBHelper(this);

        // when text sign up is clicked
        btn_signup = (TextView) findViewById(R.id.btn_signup);
        btn_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Citezens.class);
                startActivity(intent);
            }
        });
        //when button login is clicked
        btn_login = (Button) findViewById(R.id.btn_login);
        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userType = user_type.getSelectedItem().toString();

                // if the selected user type is Authority
                if (userType.equals("Authority"))
                {
                    String authEmail = login_email.getText().toString();
                    String authPass = login_password.getText().toString();

                    if (authEmail.isEmpty()||authPass.isEmpty())
                        Toast.makeText(LoginActivity.this, "Please provide Credentials!", Toast.LENGTH_SHORT).show();
                    else {
                        Boolean checkAuthorityCredentials = MyDB.checkAuthorityEmailPass(authEmail, authPass);
                        if (checkAuthorityCredentials==true) {
                            Toast.makeText(LoginActivity.this, "Successfully Signed In!", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), AuuthorityHome.class);
                            startActivity(intent);
                        }
                    }
                }
                // if the selected user is citizen
                else if (userType.equals("Citizen"))
                {
                    String citizen_mail = login_email.getText().toString();
                    String citizen_pass = login_password.getText().toString();

                    if (citizen_mail.isEmpty()||citizen_pass.isEmpty())
                        Toast.makeText(LoginActivity.this, "Please provide Credentials!", Toast.LENGTH_SHORT).show();
                    else {
                        Boolean checkCitizenCredentials = MyDB.checkCitizenEmailPass(citizen_mail, citizen_pass);
                        if (checkCitizenCredentials==true) {
                            Toast.makeText(LoginActivity.this, "Successfully Signed In!", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), CitizenHome.class);
                            startActivity(intent);
                        }else
                            Toast.makeText(LoginActivity.this, "Invalid Credentials!", Toast.LENGTH_SHORT).show();
                    }
                }
                // if selected user is the health organization
                else if(userType.equals("Health_Organization"))
                {
                    String healthEmail = login_email.getText().toString();
                    String healthPass = login_password.getText().toString();

                    if (healthEmail.isEmpty()||healthPass.isEmpty())
                        Toast.makeText(LoginActivity.this, "Please Provide Credentials", Toast.LENGTH_SHORT).show();
                    else {
                        Boolean checkHealthCredentials = MyDB.checkHealthEmailPass(healthEmail, healthPass);
                        if (checkHealthCredentials==true) {
                            Toast.makeText(LoginActivity.this, "Successfully Signed In!", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), HealthHome.class);
                            startActivity(intent);
                        }else
                            Toast.makeText(LoginActivity.this, "Invalid Credentials!", Toast.LENGTH_SHORT).show();
                    }
                }
                // if the selected user is non health organization
                else if(userType.equals("Non_Health_Organization"))
                {
                    String nonHealthEmail = login_email.getText().toString();
                    String nonHealthPass = login_password.getText().toString();

                    if (nonHealthEmail.isEmpty()||nonHealthPass.isEmpty())
                        Toast.makeText(LoginActivity.this, "Please provide credentials!", Toast.LENGTH_SHORT).show();
                    else {
                        Boolean checkNonCredentials = MyDB.checkNonHealthEmailPass(nonHealthEmail, nonHealthPass);
                        if (checkNonCredentials==true) {
                            Toast.makeText(LoginActivity.this, "Successfully Signed In!", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), NonHealthHome.class);
                            startActivity(intent);
                        }else
                            Toast.makeText(LoginActivity.this, "Invalid Credentials!", Toast.LENGTH_SHORT).show();
                    }

                }
                clearFields();
            }

        });
    }

    private void clearFields() {
        login_email.setText(null);
        login_password.setText(null);
    }
}