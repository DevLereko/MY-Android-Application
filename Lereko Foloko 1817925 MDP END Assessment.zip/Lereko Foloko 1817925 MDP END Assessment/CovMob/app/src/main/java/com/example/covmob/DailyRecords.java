package com.example.covmob;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class DailyRecords extends AppCompatActivity {

    Spinner citizen_origin;
    EditText national_id, reg_date, citizen_name, temp_citizen, citizen_phone, citizen_organization_name;
    Button search_Citizen_daily, btn_submit_daily, btn_delete_daily;
    TextView citizen_daily_login;
    String[] gender = {"Male", "Female"};
    String[] place = {"Maseru", "Botha-Bothe", "Leribe", "Berea", "Mafeteng", "Mohale's Hoek",
            "Mokhotlong", "Thaba-Tseka", "Qacha's Nek", "Quthing"};
    public  static String searchCitizen;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daily_records);

        citizen_origin = (Spinner) findViewById(R.id.citizen_origin);

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(DailyRecords.this, android.R.layout.simple_spinner_item, place);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        citizen_origin.setAdapter(arrayAdapter);

        national_id = (EditText) findViewById(R.id.national_id);
        reg_date = (EditText) findViewById(R.id.reg_date);
        citizen_name = (EditText) findViewById(R.id.citizen_name);
        temp_citizen = (EditText) findViewById(R.id.temp_citizen);
        citizen_phone = (EditText) findViewById(R.id.citizen_phone);
        citizen_organization_name = (EditText) findViewById(R.id.citizen_organization_name);
        final DBHelper MyDataBase = new DBHelper(this);

        //when button search is clicked ---------------//
        search_Citizen_daily = (Button) findViewById(R.id.search_Citizen_daily);
        search_Citizen_daily.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchCitizen = national_id.getText().toString();
                searchNationalID();
            }
        });
        //when button Update is clicked ----------//
        btn_submit_daily = (Button) findViewById(R.id.btn_submit_daily);
        btn_submit_daily.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String citizenID = national_id.getText().toString();
                String regDate = reg_date.getText().toString();
                String Name = citizen_name.getText().toString();
                String temp = temp_citizen.getText().toString();
                String phones = citizen_phone.getText().toString();
                String origin = citizen_origin.getSelectedItem().toString();
                String orgNames = citizen_organization_name.getText().toString();

              boolean isUpdate = MyDataBase.UpdateRecords(citizenID, regDate, Name, temp, phones, origin, orgNames);
              if (isUpdate==true) {
                  Toast.makeText(DailyRecords.this, "Data Updated Successfully!", Toast.LENGTH_SHORT).show();
              }else
                  Toast.makeText(DailyRecords.this, "Failed to update!", Toast.LENGTH_SHORT).show();
              clearTexts();
            }
        });
        //when delete daily button is clicked
        btn_delete_daily = (Button) findViewById(R.id.btn_delete_daily);
        btn_delete_daily.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String citizenID = national_id.getText().toString();
                Integer deleteRows = MyDataBase.deleteData(citizenID);
                if (deleteRows > 0)
                    Toast.makeText(DailyRecords.this, "Data Successfully Deleted!", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(DailyRecords.this, "Failed to Delete Data!", Toast.LENGTH_SHORT).show();
                clearTexts();
            }
        });
        //when text Register is clicked ----------------//
        citizen_daily_login = (TextView) findViewById(R.id.citizen_daily_login);
        citizen_daily_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Citezens.class);
                startActivity(intent);
            }
        });
    }
    // ---------------search for national id before updating records
    private void searchNationalID() {
        searchCitizen = national_id.getText().toString();
        DBHelper database = new DBHelper(this);

        String name = null, phone = null, temp = null, names = null;

        Cursor cursor = database.getCitizenDetails(searchCitizen);
        cursor.moveToNext();
        if (cursor.getCount() <= 0)
        {
            Toast.makeText(this, "User Not Registered!", Toast.LENGTH_SHORT).show();
        }
        else
        {
            name = cursor.getString(2);
            phone = cursor.getString(4);
            temp = cursor.getString(5);
            names = cursor.getString(9);

            citizen_name.setText(name);
            citizen_phone.setText(phone);
            temp_citizen.setText(temp);
            citizen_organization_name.setText(names);
        }
    }
    //clearTexts after update
    public void clearTexts () {
        national_id.setText(null);
        reg_date.setText(null);
        citizen_name.setText(null);
        temp_citizen.setText(null);
        citizen_phone.setText(null);
        citizen_organization_name.setText(null);
    }
}